#!/bin/bash
export PDO_PGSQL_TEST_DSN='pgsql:host=localhost port=5432 dbname=test user=postgres password='