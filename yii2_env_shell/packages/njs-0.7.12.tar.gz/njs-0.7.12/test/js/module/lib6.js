var obj = {
  a:1,
  b:2
}

export {obj as default};
