function hash() {
    return sub2.hash(crypto);
}

function error() {
    return {}.a.a;
}

import sub2 from 'sub2.js';
import crypto from 'crypto';

export default {hash, error};
