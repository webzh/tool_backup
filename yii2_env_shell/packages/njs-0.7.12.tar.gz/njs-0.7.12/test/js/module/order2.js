if (!globalThis.stages) {
    globalThis.stages = [];
}

globalThis.stages.push('order2');

export default 1;
