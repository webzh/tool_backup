var uu = 10;
var uu1 = 11;

export { uu as default };

export { uu1 as default };
