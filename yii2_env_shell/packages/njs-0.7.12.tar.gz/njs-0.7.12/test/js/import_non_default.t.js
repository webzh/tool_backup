/*---
includes: []
flags: []
paths: [test/js/module, test/js/module/libs]
negative:
  phase: runtime
---*/

import m from 'export_non_default.js';
