/*---
includes: []
flags: []
paths: []
negative:
  phase: runtime
---*/

import name   from 'name.js';
