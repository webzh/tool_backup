if (typeof print !== 'function') {
    globalThis.print = console.log;
}
