
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_MATH_H_INCLUDED_
#define _NJS_MATH_H_INCLUDED_


extern const njs_object_init_t  njs_math_object_init;


#endif /* _NJS_MATH_H_INCLUDED_ */
